#!/bin/bash
./table-client 127.0.0.1:44444 127.0.0.1:44445 
