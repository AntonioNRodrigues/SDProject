# SDProject

Sistemas Distribuidos 2016/2017

<h4>Grupo 33 </h4>

<ul>
<li>Miguel Vale n.º39279  </li> 
<li>António Rodrigues n.º40853  </li>
<li>Ricardo Veloso n.º44842  </li>
</ul>


<h6>1.ºFase<h6>
<h6>2.ºFase<h6>

<ul>
<li>Run Server:: ./table-server tcp_port size_table</li>
<li>Run Client:: ./table-client ip_server:port_server</li>
</ul>





