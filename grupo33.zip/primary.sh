	#!/bin/bash
	./table-server 44444 10 127.0.0.1:44445
