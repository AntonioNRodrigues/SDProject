	#!/bin/bash
	./table-server 44445 10
